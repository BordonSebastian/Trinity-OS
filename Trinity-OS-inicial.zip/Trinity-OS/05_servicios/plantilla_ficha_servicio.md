# Nombre del servicio

**Estado:** PLANTILLA

## Resumen

## Problema que resuelve

## Cliente ideal

## Beneficios

## Alcance habitual

## Funcionalidades

## Proceso de implementación

## Entregables

## Dependencias del cliente

## Plazo estimado

## Modalidad comercial

## Soporte

## Objeciones frecuentes

## Evidencia y casos relacionados

## CTA aprobado
