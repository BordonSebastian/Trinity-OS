# Identidad visual

**Estado:** BORRADOR

## Paleta base

| Uso | Color |
|---|---|
| Primario | `#9D0000` |
| Fondo oscuro | `#2A2A2A` |
| Texto secundario | `#646464` |
| Fondo claro | `#FFFFFF` |
| Fondo alternativo | `#F5F5F5` |

## Dirección visual

La marca debe transmitir:

- Tecnología empresarial.
- Orden.
- Solidez.
- Precisión.
- Modernidad.
- Confianza.

## Criterios

- Composiciones limpias.
- Jerarquía tipográfica clara.
- Uso moderado del rojo.
- Capturas reales de sistemas.
- Mockups sobrios.
- Poco texto por pieza.
- Espacio negativo suficiente.
- Evitar recursos visuales genéricos de “tecnología futurista”.

## Pendientes

- Definir tipografía principal.
- Definir tipografía secundaria.
- Normalizar variantes del logo.
- Crear sistema de iconografía.
- Crear plantillas para redes.
- Crear estilos de fotografía y video.
