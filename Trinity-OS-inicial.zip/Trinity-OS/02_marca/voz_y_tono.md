# Voz y tono de Trinity

**Estado:** BORRADOR

## Voz

Trinity comunica con claridad, criterio técnico y orientación empresarial.

## Tono

- Profesional.
- Directo.
- Seguro, sin arrogancia.
- Cercano, sin exceso de informalidad.
- Comercial, sin promesas vacías.
- Técnico cuando el público lo requiere.

## Preferencias de redacción

- Hablar de problemas y resultados.
- Usar frases concretas.
- Explicar tecnología en términos de negocio.
- Priorizar verbos de acción.
- Incluir llamadas a la acción claras.

## Evitar

- “Revolucionamos tu negocio”.
- “La mejor solución del mercado”.
- “Tecnología de punta” sin evidencia.
- Párrafos saturados de palabras técnicas.
- Exceso de emojis.
- Frases motivacionales sin relación con el servicio.
