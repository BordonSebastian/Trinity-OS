# Gestión documental de Trinity OS

**Estado:** VIGENTE

## Objetivo

Mantener la base de conocimiento actualizada, confiable y utilizable.

## Flujo

1. Crear documento en estado `BORRADOR`.
2. Completar información y fuentes.
3. Validar con el responsable.
4. Cambiar estado a `VIGENTE`.
5. Registrar cambios mediante commit.
6. Revisar al menos una vez al año.
7. Mover versiones reemplazadas a `99_archivo`.

## Responsables

- Dirección: aprobación de estrategia, marca y política comercial.
- Comercial: servicios, objeciones, procesos de venta y propuestas.
- Operaciones: implementación, soporte y procedimientos.
- Marketing: campañas, contenido, voz y activos.
- Tecnología: estándares técnicos, arquitectura y seguridad.
