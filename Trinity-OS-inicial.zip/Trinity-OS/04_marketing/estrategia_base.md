# Estrategia base de marketing

**Estado:** BORRADOR

## Objetivo principal

Generar confianza, autoridad y oportunidades comerciales B2B para Trinity.

## Prioridades

1. Demostrar experiencia real.
2. Explicar problemas empresariales que Trinity resuelve.
3. Mostrar sistemas, procesos e implementaciones.
4. Humanizar la empresa mediante equipo, clientes y trabajo real.
5. Convertir atención en conversaciones comerciales.

## Canales prioritarios

- Instagram.
- LinkedIn.
- Facebook.
- WhatsApp Business.
- Sitio web.
- Email.

## Distribución recomendada del contenido

- 35% educación empresarial.
- 25% casos, proyectos y evidencia.
- 20% servicios y soluciones.
- 10% cultura y equipo.
- 10% opinión y posicionamiento.

## Métricas iniciales

- Consultas calificadas.
- Reuniones generadas.
- Presupuestos originados por contenido.
- Alcance al público objetivo.
- Guardados y compartidos.
- Visitas al perfil y sitio.
