# Cliente ideal

**Estado:** BORRADOR

## Perfil general

Empresa con operación activa, varios procesos administrativos, necesidad de control y disposición para invertir en una solución de mediano o largo plazo.

## Señales positivas

- Usa planillas, sistemas desconectados o procesos manuales.
- Tiene más de una sucursal, área o responsable.
- Necesita información gerencial.
- Experimenta errores, retrabajo o falta de trazabilidad.
- Cuenta con una persona responsable del proyecto.
- Tiene presupuesto y capacidad de decisión.
- Valora soporte y continuidad.

## Señales de riesgo

- Busca copiar un sistema complejo con presupuesto mínimo.
- No asigna responsables internos.
- Cambia constantemente el alcance sin aceptar impacto.
- Espera que la tecnología corrija problemas de gestión sin modificar procesos.
- Rechaza documentación, validación o capacitación.
