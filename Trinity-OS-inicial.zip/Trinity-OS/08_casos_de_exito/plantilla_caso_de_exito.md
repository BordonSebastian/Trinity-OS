# Nombre del caso de éxito

**Estado:** PLANTILLA

## Cliente

## Rubro

## Situación inicial

## Problema

## Impacto del problema

## Solución desarrollada

## Proceso de implementación

## Funcionalidades relevantes

## Resultado

## Métricas

## Testimonio

## Recursos disponibles

- Capturas:
- Fotografías:
- Video:
- Logo autorizado:
- Permiso para publicación:

## Mensajes de marketing derivados
